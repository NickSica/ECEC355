# ECEC355   
This is to help guide you, not for cheating purposes.   
If you are reading this when I'm out of the class go ahead and do whatever, you'll get caught if it is very obvious.   
If I'm currently taking the class(Summer 2019), don't screw me because I wanted to be nice and help.
